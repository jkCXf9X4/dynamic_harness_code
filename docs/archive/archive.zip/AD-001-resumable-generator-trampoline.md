---
id: AD-001
type: decision
title: "Kernel made real"
summary: "The turn engine is a workspace-owned, agent-authored resumable generator that the runtime pumps one yield-window at a time."
date: 2026-10-07
status: accepted
layers: [architecture]
state: breakdown/02-architecture/the-kernel-made-real.md
artifacts:
  - src/dhc/framework/repl.py
  - src/dhc/framework/pump.py
  - tests/test_imp001_acceptance.py
supersedes: []
superseded_by: []
related:
  - IMP-001
  - INFO-020
  - INFO-005
  - INFO-038
  - AD-003
  - AD-004
  - AD-006
  - TC-001
---

# AD-001: Kernel made real

## Context

The committed runtime's agent loop is fixed: `Runtime._worker_loop` → `LLMDriver` → one `ReplEngine.execute` per turn, so orchestration (decide, run, observe, settle) is hard-coded in runtime code — an agent cannot author, view, or replace its own loop, inject guardrails, or experiment with control flow.
IMP-001 proposes making the turn engine a workspace-resident, agent-authored resumable generator (`__runner`) that the runtime pumps one yield-window (step) at a time.
The scoping question is which execution foundation realizes this: a resumable generator, a runtime-pumped step-function, the unchanged turn loop, or a full interpreter rewrite.

## Decision

The foundation is a resumable generator / trampoline pumped by the runtime: each agent's main loop is a generator in its own workspace globals (`__runner`), and the runtime shrinks to a pump that advances it one yield-window, classifies the yield, enforces gates, and repeats.
A yield is a checkpoint, so snapshots, cancellation, and per-step budgeting become exact.
Containment reuses the proven thread + snapshot net (INFO-020); the workspace is the blast radius (INFO-005, INFO-038).

## Rationale

Only a resumable runner gives the agent true authorship of the whole loop while keeping preemption and per-step budgets in the runtime.
Yields as checkpoints make snapshots, cancellation, and budget enforcement exact.
The thread + snapshot containment net is already proven in `ReplEngine` (per-agent lock, daemon worker thread, `join(timeout)`, rollback to turn-start snapshot), so the trampoline reuses existing machinery rather than inventing new preemption.

## Alternatives Considered

- Runtime-pumped step-function — cadence stays runtime-owned; weakens "full control" and re-creates the injection-channel problem. Rejected.
- Keeping the current driver loop — the pain (lossy context, fixed loop, no custom guardrails, blocking supervision) stands unchanged. Rejected.
- Full interpreter rewrite with preemption at arbitrary points — unsafe; the thread + snapshot net is already proven and cheaper. Rejected.

## Consequences

- `ReplEngine` gains resumable-run primitives: `install` / `advance` / `inject` / `suspend` / `resume` / `kill`, plus `run_block` (non-locking nested exec honoring the outer step budget) and per-advance snapshots; `execute` is retained for the default path.
- A generator that never yields (`while True: pass`) is contained by the step timeout → snapshot rollback → generator abandoned; the pump resets from checkpoint or settles.
- Generator thread affinity must be explicit in the contract: an abandoned generator is never resumed (the old thread mutates only the discarded snapshot dict), so sequential join-ordered advances are safe.
- Nested `run_block` reentrancy bypasses the per-agent lock at a deeper level; a runaway nested block is caught only by the outer step timeout — acceptable, must be documented.

## Verification

`tests/test_imp001_acceptance.py::test_d1_custom_runner_trampoline` exercises the trampoline; the acceptance fixture's gate tests (AD-002) and the D3 no-step-budget-burn test (AD-003) cover the pump's servicing.

## Review Trigger

Revisit if the pump's per-step budgeting proves too coarse for long-running blocks, or if a cheaper preemption mechanism than thread + snapshot emerges.
