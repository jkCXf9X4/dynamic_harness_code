---
id: IMD-003
title: Token/cost accumulation at the driver seam
summary: Usage accumulates at the driver seam with one write and one read, and the mock path reports zeros.
date: 2026-10-08
status: accepted
layers: [implementation]
state: breakdown/03-implementation/state-view-model.md
artifacts:
  - src/dhc/llm/llm.py
  - src/dhc/llm/driver.py
  - src/dhc/framework/agent.py
  - src/dhc/ui/state.py
  - tests/framework/test_token_cost.py
supersedes: []
superseded_by: []
related: [IMP-004, AD-002, AD-004]
---

# IMD-003: Token/cost accumulation at the driver seam

## Context
`IMP-004` documents the hazard: `AgentNode` (then `src/dhc/agent/state.py:78-95`; now `src/dhc/ui/state.py`) carries `tokens`, `messages`, `context_tokens`, `prompt_tokens`, `completion_tokens`, `cached_tokens`, `cost_usd`, and `cum_cost_usd` — all defaulting to zero — and no code path ever assigns them.
The state view-model therefore "lies by default": `AgentNode.usage` renders nothing, so an operator inspecting a live agent (the `operator.inspect` window, `IMP-001` D2) sees no usage at all, and any future budget or rot policy that wants a token signal has no signal to read.
The data already exists at the driver boundary: `LLMResponse` (`src/dhc/llm/llm.py:93-100`) carries `usage` (a dict with `prompt_tokens`/`completion_tokens`/`cached_tokens`, built at `llm.py:355-370`) and `cost_usd` (estimated at `llm.py:348`), so the provider call already measures what the view-model claims to report, and the value is simply dropped on the way to the agent's state.
The drop happens at a specific seam: `LLMClient.generate_code_block` (`llm.py`) calls `self._provider.generate(...)` — which returns the full `LLMResponse` with `usage`/`cost_usd` — and then returns only `_strip_markdown_fences(response.text)`, discarding the usage at that line.
`LLMDriver.__call__` (`src/dhc/llm/driver.py`) is the one place that holds both the agent (the live object in `runtime._agents`) and the client (`self._client`), so it is the natural accumulation point.
The mock path must stay zero: `MockDriver` (the default fabrication brain, `AD-004`) and `MockLLM` return no usage, so the propagation must be None-safe, keeping the default loop's behavior unchanged and the mock path reporting zeros, not a crash and not a fabricated number.

## Decision
Accumulate usage at the driver seam, with one write and one read (seam mechanics in `INFO-059`).
1. The client records the last response's usage on itself after each `generate_code_block`; `MockLLM` leaves it `None` and never fabricates usage.
2. The driver is the one write seam: `LLMDriver.__call__` reads the client's last usage and calls `agent.record_usage` when present; `MockDriver` never calls it (no client), so the mock path writes nothing.
3. `Agent.record_usage` is the one accumulation point: it adds the token counts and `cost_usd` into per-agent accumulators (`_prompt_tokens`, `_completion_tokens`, `_cached_tokens`, `_cost_usd`), None-safe so a `None` usage or missing key contributes nothing.
4. `build_agent_tree` is the one read seam: it copies the agent's accumulated usage (and `tokens = prompt + completion`) into `AgentNode`, and `build_stats` aggregates the node values into `Stats`, so `stats.json` reports real totals.
The zero-cost mock path reports zeros: `MockDriver`/`MockLLM` never set usage, so `record_usage` is never called and the view-model renders zero defaults.

## Rationale
- One provenance, by construction: the `IMP-004` leaf demands one accumulation point so the view-model's numbers have a single provenance; writing at the driver seam (the only place holding both the agent and the client) and reading at `build_agent_tree` (the only place that builds the view-model) gives exactly one writer and one reader, and a double-count would require a second writer the design does not provide.
- The driver seam is where the data and the agent already meet: `LLMDriver.__call__(agent)` receives the live `Agent` and owns `self._client`, so no new object, thread, or event is needed, and the usage is read off the client that just produced it and written onto the agent that just consumed the block.
- None-safety keeps the mock path byte-identical: `MockDriver` has no client and `MockLLM` sets no usage, so the accumulation is a no-op on the default path, and the existing 483-test suite (which exercises the mock path pervasively) stays green with no test weakened.
- The view-model is unchanged in shape: `AgentNode` already has the fields and `build_agent_tree` already builds the node, so we only populate the fields from the agent's accumulators, with no new field, file, or public API.

## Alternatives Considered
- (b) Accumulate in `LLMClient.generate_code_block` itself. Rejected: the client does not hold the agent — it only sees the prompt — so it would need a back-reference to the agent, coupling the LLM layer to the agent layer and creating a second, less-obvious write path; the driver already holds both.
- (c) Accumulate in the pump loop after `driver(agent)`. Rejected: the pump calls `driver(agent)` and only sees the returned `str` (or `None`) — the usage is not in the return value — so the pump would have to reach into the client/driver internals, scattering the read across the loop; the driver is the tighter seam.
- (d) Emit a usage event and have `StateWriter` accumulate it. Rejected: it adds an event kind, a bus subscription, and a second accumulation site (the writer), violating "one accumulation point" and coupling the view-model to the event stream for a value that is already on the agent.
- (e) Store usage on the `LLMResponse` and thread it through the driver's return value. Rejected: it changes the driver's `-> str | None` contract (a public, tested surface) to `-> (str, usage) | None`, a larger blast radius than reading an attribute off the client the driver already owns.

## Consequences
- Operators now see real token/cost figures in `agents.txt` and `stats.json` after LLM-driven runs; the `operator.inspect` window (`IMP-001` D2) has a token signal to read.
- `cost_usd` is a provider estimate, not a billing figure; the view-model reports it as such (`INFO-059`).
- The mock path is unchanged: zeros, no crash, no fabricated number.
- Open, deferred per the `IMP-004` leaf: whether `messages` (also inert) is populated from the same seam, and whether `context_tokens` derives from the digest size or the provider's `prompt_tokens`; both are out of scope here, and the seam is shaped so either can be added without a second write path (`INFO-059`).

## Verification
Full suite green in a single run: 492 passed (483 baseline plus 9 new), no test weakened.
New tests, all in `tests/framework/test_token_cost.py`:
1. `test_record_usage_accumulates` — two calls with usage sum exactly (no double count); a `None`-usage call adds nothing.
2. `test_driver_writes_usage_to_agent` — a spy client returning a usage dict drives `LLMDriver.__call__`; the agent's `prompt_tokens`/`completion_tokens`/`cost_usd` are non-zero and cumulative.
3. `test_no_usage_leaves_agent_zero` — a client with no usage leaves the agent's fields at zero (no crash, no fabricated number).
4. `test_mock_path_reports_zeros` — `MockDriver`/`MockLLM` run to settlement; `build_agent_tree`/`build_stats` report zeros and `AgentNode.usage` renders the empty string.
5. `test_agents_txt_and_stats_report_real_values` — an LLM-driven run (spy client with usage) through the pump; `agents.txt` shows the token figures and `stats.json` shows the aggregated totals.

## Review Trigger
None
