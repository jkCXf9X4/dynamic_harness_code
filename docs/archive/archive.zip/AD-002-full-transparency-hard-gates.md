---
id: AD-002
type: decision
title: "Four hard gates are pump behavior"
summary: "The agent sees and edits its whole workspace, bounded only by four hard gates that are pump behavior, not variables."
date: 2026-10-07
status: accepted
layers: [architecture]
state: breakdown/02-architecture/the-kernel-made-real.md
artifacts:
  - src/dhc/framework/pump.py
  - src/dhc/ui/operator.py
  - tests/test_imp001_acceptance.py
supersedes: []
superseded_by: []
related:
  - INFO-050
  - INFO-046
  - INFO-005
  - INFO-040
  - AD-005
  - IMD-001
  - IMD-003
  - AD-011
  - TC-001
---

# AD-002: Four hard gates are pump behavior

## Context

The model's context is lossy and runtime-squeezed: `LLMDriver._build_prompt` feeds the model only the agent's requirement, acceptance, status and the last ~5 events (`LLMDriver._recent_context`, `limit=5`, 200 chars each), and `runtime.events` drains the stream — consumed events never come back.
The persistent REPL workspace (INFO-050), which actually accumulates the agent's knowledge, is never summarized for the model, so any multi-turn agent is working blind on its own history.
The scoping question is how much of its own workspace an agent may see and edit: everything, or a layered digest.

## Decision

The agent sees and may edit everything in its own workspace — budgets, tripwires, guardrails, and the loop itself — apart from four non-negotiable gates that are pump behavior, not variables:
1. Settlement at-most-once (INFO-046) — a settled agent cannot be re-settled; the completion log is the single source of truth.
2. Crash containment / blast radius (INFO-005) — a broken loop costs one agent, not the mesh; failures are contained values.
3. Outer ceiling caps (wall-clock, step count, workspace size, child count, message rate) — enforced by the pump, not agent code.
4. Cancellation grace (INFO-040) — cancellation lands between steps; a generator that ignores it is killed, rolled back, and settled.
Full transparency also kills the injection-channel problem: there is no separate channel for messages/guardrails/context because the agent is the loop and reads/edits them as ordinary data.

## Rationale

Maximum autonomous experimentation is the point of the change; the gates guarantee a hostile or degrading workspace cannot take down the mesh.
The gates are pump behavior, not variables, so a degrading agent cannot silently edit its way out of them.
Full transparency removes the runtime-squeezed read model that is the root pain of the current design.

## Alternatives Considered

- Layered visibility (normative open, operational digest) — safer, but leaves a runtime-squeezed read model and re-creates an injection mechanism. Rejected in favor of transparency for this candidate.

## Consequences

- `operator.inspect(agent_id)` becomes a legitimate read-only window into a live workspace (full transparency makes it safe).
- The pump owns enforcement timing for the four gates; agent code cannot override them.
- Ceiling-cap defaults are added to `config.py` (wall-clock, steps, workspace bytes, children, messages).
- The hard-gate count stays exactly four for this IMP; whether it grows is an open question tracked in the IMP's risks.

## Verification

The acceptance fixture's four gate tests — `test_d2a_settlement_at_most_once`, `test_d2b_crash_containment_broken_loop`, `test_d2c_outer_ceiling_cap`, `test_d2d_cancellation_grace` in `tests/test_imp001_acceptance.py` — each prove one gate holds.

## Review Trigger

Revisit if a fifth hard gate is needed (the count is deliberately fixed at four for this IMP) or if full transparency proves unsafe in practice.
