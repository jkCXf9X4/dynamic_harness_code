---
id: OD-001
type: decision
title: "Deprecation ruling — pre-studies and analysis artifacts are transient, retired by deletion"
summary: Pre-studies and analysis artifacts are transient working documents, retired by deletion once their decisions land; future deprecations of STATE files follow the deprecated-files protocol (retire into the archive deprecated/ namespace).
date: 2026-10-09
status: accepted
layers: [operation]
state: breakdown/README.md
artifacts:
  - .agents/skills/product-breakdown/guidelines/deprecated-files.md
supersedes: []
superseded_by: []
related: [AD-005]
---

# OD-001: Deprecation ruling — pre-studies and analysis artifacts are transient, retired by deletion

## Context

Pre-study and mockup files under `breakdown/zzz_depricated/` and
`breakdown/02-architecture/pre-studies/` were deleted outright across four
commits (2026-10-06 to 2026-10-08) with no tombstone and no decision record.
The audit (STALE-3) flagged the gap: the deprecation protocol requires history
to record retirements, and a reader cannot find the rule the deletions decided.

## Decision

Pre-studies and analysis artifacts are transient working documents, retired by
deletion once their decisions land — no tombstone, no archive entry.
Future deprecations of STATE files follow the deprecated-files protocol:
retire into the archive `deprecated/` namespace, never delete outright.

## Rationale

- A pre-study or analysis is a working document, not state: its value is the
  decision it feeds, which lands in a record and an owning leaf.
- Deleting a transient document once its decision lands is the correct
  disposition — archiving it would accumulate dead material.
- STATE files are different: they are current state, and their retirement is a
  deprecation event the protocol records (tombstone in the archive).
- The ruling is an operation-layer choice: it governs the routine maintenance
  of the breakdown's own files, not the system's design.

## Alternatives Considered

- Archive every pre-study into the `deprecated/` namespace — rejected:
  accumulates dead working documents that no longer carry state.
- Keep a per-file tombstone for each deleted pre-study — rejected: the
  decision record (this one) is the single home for the ruling.

## Consequences

- Positive: the deletion of the pre-study/mockup files is now a recorded,
  ruled event; a reader meeting the gap finds this record.
- Positive: the boundary is explicit — transient documents die, STATE files
  are retired into the archive.
- Evidence — the 20 removed paths, recovered from git history (commits
  `db9b424`, `98dc727`, `dc546ba`, `25bab3d`):

```
breakdown/02-architecture/pre-studies/mockups/README.md
breakdown/02-architecture/pre-studies/mockups/await-and-callback.py
breakdown/02-architecture/pre-studies/mockups/cancel-a-straggler.py
breakdown/02-architecture/pre-studies/mockups/fan-out-research.actor.py
breakdown/02-architecture/pre-studies/mockups/fan-out-research.py
breakdown/02-architecture/pre-studies/mockups/hello-turn.py
breakdown/02-architecture/pre-studies/mockups/requirements.md
breakdown/02-architecture/pre-studies/mockups/_support.py
breakdown/02-architecture/pre-studies/mockups/mock_batch_loop.py
breakdown/02-architecture/pre-studies/mockups/mock_delegation_fan_out.py
breakdown/02-architecture/pre-studies/mockups/mock_persistent_repl_tools.py
breakdown/02-architecture/pre-studies/mockups/mock_single_turn.py
breakdown/zzz_depricated/code-capabillity/give-agents-an-in-code-capability-surface.example.py
breakdown/zzz_depricated/code-capabillity/give-agents-an-in-code-capability-surface.md
breakdown/zzz_depricated/code-capabillity/give-agents-an-in-code-capability-surface.verbs.md
breakdown/zzz_depricated/commit-to-a-minimal-execution-core-contract.analysis.md
breakdown/zzz_depricated/commit-to-a-minimal-execution-core-contract.md
breakdown/zzz_depricated/harness-design-model.md
breakdown/zzz_depricated/recommended-minimal-harness-contract.md
breakdown/zzz_depricated/runtime-architecture-selection.md
```

## Verification

`git log --diff-filter=D --name-only --all -- 'breakdown/zzz_depricated/*'
'breakdown/02-architecture/pre-studies/*'` reproduces the 20 removed paths
above; both directories are absent from the working tree.

## Review Trigger

If a pre-study or analysis artifact is ever needed as durable state, revisit
the transient-by-deletion ruling and route it through the deprecated-files
protocol instead.
