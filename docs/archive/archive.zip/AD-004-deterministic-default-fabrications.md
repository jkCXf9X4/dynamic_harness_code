---
id: AD-004
type: decision
title: "Default ships as fabrication kit"
summary: "Every workspace is born with a fabrication kit whose defaults replicate today's loop exactly; backward compatibility is the default fabrication, not a second path."
date: 2026-10-07
status: accepted
layers: [architecture]
state: breakdown/02-architecture/the-kernel-made-real.md
artifacts:
  - src/dhc/tooling/fabrication.py
  - examples/value_demo.py
  - src/dhc/llm/driver.py
supersedes: []
superseded_by: []
related:
  - AD-001
  - INFO-041
  - IMD-001
  - IMD-003
  - AD-011
  - TC-001
---

# AD-004: Default ships as fabrication kit

## Context

The `MockDriver` suite, the operator/root door, and `examples/value_demo.py` all depend on the current driver contract (`__call__(agent) -> str | None`) and the current turn loop.
Moving the loop into the workspace (AD-001) risks breaking every existing test unless the default workspace behavior replicates today's behavior exactly.
The scoping question is how backward compatibility is provided: a default fabrication kit, no default at all, or a parallel legacy path.

## Decision

Every workspace is born with a fabrication kit whose defaults replicate today's behavior exactly: the default `__runner` (the resumable generator reproducing the current turn loop), `decide(context)` (wrapping the current LLM/Mock brain), `run_block`, `context` (guardrails/inbox/outbox/budgets/digests), channel handles (`messenger`, `room`, `escalate`, `ask`), checkpoint/rollback/compact helpers, and a visible caps view.
`driver.__call__` becomes the default `decide` fabrication; its bookkeeping (`_turns`, `_calls`) moves into workspace state.
`ensure_fabrication` re-seeds any fabrication the agent broke or deleted (e.g. `__runner = 42` → re-seed the default; event emitted).
Backward compatibility is "the default fabrication," not a second execution path: there is exactly one loop, and the default `__runner` is what the current loop becomes (INFO-037).

## Rationale

The `MockDriver` suite and operator/root door keep their contracts and determinism on the default loop; backward compatibility is the default fabrication, not a second execution path — two loops to maintain is the failure mode this decision avoids.
`ensure_fabrication` makes the default loop None-safe: a broken or deleted fabrication is re-seeded on demand, so a degrading agent cannot take itself (or the mesh) down by breaking its own workspace.

## Alternatives Considered

- No default (agents must bootstrap a loop) — breaks all existing tests and the operator/root door. Rejected.
- A separate legacy path in parallel — two loops to maintain, and the legacy path becomes a permanent second execution path. Rejected.

## Consequences

- `driver.py`: `__call__` becomes the default `decide(context)` fabrication; prompt assembly becomes a fabrication; rot observation moves into the default loop's observe step.
- `wiring.py` / `agent.py`: inject the fabrication kit into the namespace; expose `run_block`, `context`, channels as workspace citizens; `ensure_fabrication`; keep the in-code surface (INFO-041) stable on the default loop.
- The `MockDriver` integration suite and `examples/value_demo.py` must pass unmodified on the default loop — this is the backward-compat gate for the whole injection.
- Determinism: custom loops break scripted-driver tests unless policies default to the fabrications; fixtures must swap `__runner`/`decide` as cells.

## Verification

The `MockDriver` integration suite and `examples/value_demo.py` must pass unmodified on the default loop — the backward-compat gate for the whole injection (`tests/test_imp001_acceptance.py::test_d4_default_fabrication_plain_spawn`, `test_d4_ensure_fabrication_reseeds`).

## Review Trigger

Revisit if a second execution path creeps in, or if the fabrication kit's defaults drift from the committed turn loop.
