---
id: PD-001
title: "Parked-time semantics for the wall-clock ceiling: parked time is credited"
summary: Time an agent spends parked on Await or Sleep is excluded from the wall-clock ceiling; the ceiling binds all non-parked wall time and parked-forever agents are contained by cancellation.
date: 2026-10-08
status: accepted
layers: [product]
state: breakdown/01-product/the-control-split-agent-vs-runtime.md
artifacts:
  - src/dhc/framework/caps.py
  - src/dhc/framework/pump.py
  - src/dhc/framework/runtime.py
  - tests/framework/test_g05_parked_time.py
supersedes: []
superseded_by: []
related: [AD-003, AD-007, INFO-052, INFO-053]
---

# PD-001: Parked-time semantics — the wall-clock ceiling excludes time spent parked

## Context
`INFO-053` puts waiting under agent control ("waiting on others consumes no agent budget") and ceiling caps under runtime control ("wall-clock, step count, workspace size, child count, and message rate bind regardless of any budget edit the agent makes").
The implementation had freed the step budget (`AD-003`: `step_count` does not advance while parked) but not the wall clock: `started_ts` was set once at pump start and `caps_exceeded` compared raw elapsed time against `timeout_seconds`, so a parent that spawned a child and parked on `yield Await(child)` was killed at resume for the child's slowness — the wall clock ran while the parent did exactly what the vision recommends (cheap cooperation, `INFO-052`: "waiting on others does not consume an agent's own capacity to act").
The ambiguity (roadmap G-05, gap-analysis §B row A8 caveat, §D open question 1): does "agent budget" in the Waiting bullet include the wall-clock ceiling, or only the step budget?

## Decision
Parked time is excluded from the wall-clock ceiling: the pump accumulates the seconds each agent spends parked on `yield Await(child)` and `yield Sleep(t)` and passes the cumulative credit to the caps watchdog; the wall-clock check compares elapsed minus parked credit against `timeout_seconds`.
The ceiling remains a runtime guarantee that binds for all non-parked wall time — not weakened: a busy agent (steps that never park) still trips it, a runaway step is still bounded by the step timeout, and an agent that parks forever is still terminated by cancellation.
Implementation: `caps_exceeded` gains an optional `parked_seconds: float = 0.0` keyword and the wall-clock branch subtracts it (no other cap branch touched — G-01 owns the iterations branch, which remains open); the pump accumulates `parked_seconds` with `service_await`/`service_sleep` returning the parked duration (previously `bool`); the cancelled path still settles cancelled — the parked duration is simply not credited on a path that terminates; `_caps_watchdog` forwards the credit and the `_service_*` wrappers re-type to `float` (the re-export seam is preserved: the pump still calls `runtime._service_*`, so monkeypatching the Runtime methods keeps working).

## Rationale
- The vision's spirit is unambiguous even where its letter is not: `INFO-052` frames the goal as "from expensive supervision to cheap cooperation" — waiting on others must not cost the waiter. Under the old semantics the parent paid with its life for the child's slowness, the single most delegation-shaped pattern the vision exists to enable; reading "budget" as step-budget-only would make the Waiting bullet true while its motivation is false.
- Exclusion weakens nothing the ceiling actually guarantees: the wall-clock watchdog runs between steps (enforcement timing), so it already provided zero containment during a park — a parent parked on a never-settling child was already beyond the wall clock's reach. What contains a parked-forever agent is cancellation, unchanged and now pinned by test; runaway steps are contained by the per-step timeout and the iterations cap, both untouched.
- The alternative — bind while parked, documenting the status quo as "the wall clock is a mesh-survival guarantee, not an agent budget" — has no compensating strength: the mesh-survival story for parked agents was never carried by the wall clock but by cancellation, so it would preserve a guarantee that does not exist while keeping the anti-pattern penalty.
- The credit is bounded and runtime-owned: the accumulator lives in pump code the agent cannot edit (caps read runtime state only); the credit is clamped at zero below and can never exceed elapsed time because the pump itself measures it around `engine.suspend`/`engine.resume`.

## Alternatives Considered
- Wall clock binds while parked (status quo, documented). Rejected on the rationale above: it keeps punishing the delegation pattern and defends a guarantee the wall clock never actually provided.
- Credit only Await-parks, not Sleep-parks ("waiting on others"). Rejected: textually defensible, but Sleep is also waiting, the distinction is invisible to the agent, and it doubles the accounting surface for no containment gain.
- A separate parked-time ceiling (wall clock binds, plus a max-parked-seconds cap). Rejected: adds a sixth cap and a new config surface for a case cancellation already contains.

## Consequences
- A parent awaiting a slow child is no longer killed for the child's slowness; the child's own busy time still binds its own ceiling.
- An agent that parks forever is contained by cancellation only — now the documented containment path for parked agents; operators cancelling a mesh get parked agents killed at the next 10 ms poll (`service_await`/`service_sleep` poll the stop flag).
- The `service_await`/`service_sleep` return-type change (bool to float) is internal to the pump seam; no test or caller outside the pump modules used the old boolean (verified: no other call sites).
- Deferred interaction, discharged by `AD-007`: the credit was measured with `time.monotonic()` while the ceiling's `started_ts` and `caps_exceeded` used `time.time()` — the pre-existing mixed time base. When `AD-007` landed, the parked credit and `started_ts` moved to the same monotonic base together; until then the credit was a duration (a difference), far less exposed to wall-clock jumps than an absolute timestamp, but the mixed base remained a known defect owned by `AD-007`, not fixed here.
- G-01 (the iterations branch) remains open: no record or leaf carries it yet — noted open.

## Verification
Full suite 429 passed / 0 failed (baseline before the change: 424 passed; with `PYTHONPATH=src` — the subprocess-spawning `test_value_demo_runs_unmodified` needs it in this environment, pre-existing and unrelated). New tests, all in `tests/framework/test_g05_parked_time.py`:
1. `test_g05_parked_await_excluded_from_wall_clock` — a parent parked on `yield Await(slow_child)` for 1.5 s against a 1.0 s ceiling, child alive throughout, completes normally; no `wall_clock` crash event.
2. `test_g05_busy_agent_still_trips_wall_clock` — an agent that keeps stepping without parking trips `wall_clock` (0.05 s ceiling) with the crash event naming cap and limit.
3. `test_g05_runaway_step_still_trips_step_timeout` — `while True: pass` is still bounded by the step timeout (rollback plus timeout settlement).
4. `test_g05_cancel_terminates_parked_agent` — cancellation terminates a parked agent: settles cancelled, runner killed (`advance` to `abandoned`), child released, mesh alive.
5. `test_g05_wall_clock_credit_arithmetic` — the credit arithmetic pinned at the watchdog seam: 10 s elapsed / 5 s ceiling trips; +6 s credit does not; +4 s credit still does.

## Review Trigger
None
