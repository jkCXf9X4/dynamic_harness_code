---
id: AD-006
type: decision
title: "Event stream consumed in-loop (partial reversal of INFO-048)"
summary: "Event-stream consumption moves into the loop while the discipline (FIFO, at-most-once, persist-before-execute) stays runtime-owned."
date: 2026-10-07
status: accepted
layers: [architecture]
state: breakdown/02-architecture/resolve-the-event-stream-outside-agent-code.md
artifacts:
  - src/dhc/framework/event_stream.py
  - src/dhc/tooling/fabrication.py
supersedes: []
superseded_by: []
related:
  - AD-001
  - INFO-048
  - INFO-049
  - INFO-051
  - IMP-001
  - TC-001
---

# AD-006: Event stream consumed in-loop (partial reversal of INFO-048)

## Context

INFO-048 ruled that the runtime owns event-stream consumption: the driver drains the agent's events (`LLMDriver._recent_context`), and consumed events never come back.
The reason for the original ruling was interpreter-level locks and a private namespace — the runtime had to be the consumer because agent code could not safely read its own stream.
IMP-001 (AD-001) moves the loop into the workspace: the agent is the loop and reads its own events as ordinary data. The scoping question is whether this reverses INFO-048's discipline or only its placement.

## Decision

Partial reversal — placement, not discipline: event-stream consumption moves into the loop (the agent's `__runner` reads its own stream as part of its orchestration), but the discipline stays runtime-owned and unchanged — FIFO order, at-most-once delivery, persist-before-execute (the boundary log, INFO-049, remains the provenance backbone).
`event_stream.py` itself is unchanged — only the consumer changes.
The reason for the original ruling survives: interpreter-level locks and the private namespace are no longer a constraint because the loop now runs in the workspace, but the discipline stays external so a degrading agent cannot corrupt the stream or the log.

## Rationale

The IMP mandates recording this partial reversal in a decision record; the reversal is deliberate and bounded — consumption placement changes, discipline does not.
This preserves the guarantees that made INFO-048 correct (the boundary log is the single provenance backbone; events are delivered at most once in FIFO order) while removing the runtime-squeezed read model that was the pain.

## Alternatives Considered

- Full reversal (discipline moves into the loop too) — a degrading agent could drop, reorder, or re-deliver events; the boundary log loses its guarantee. Rejected.
- No reversal (runtime keeps consuming) — the lossy-context pain stands; the agent still works blind on its own history. Rejected.

## Consequences

- `event_stream.py`: unchanged discipline (FIFO, at-most-once, persist-before-execute); only consumption moves into the loop.
- On adoption, INFO-051 is revised to state "event-stream consumption in-loop, discipline runtime-owned"; INFO-048's ruling is amended by this record.
- Per-step events flow through the boundary log (INFO-049) as before.

## Verification

`tests/framework/test_event_stream.py` exercises the unchanged discipline (FIFO, at-most-once, persist-before-execute); the in-loop consumer is exercised by the fabrication kit's default `__runner` (`tests/test_imp001_acceptance.py`).

## Review Trigger

Revisit if the discipline (FIFO, at-most-once, persist-before-execute) ever needs to move into the loop, or if INFO-051's in-loop consumption is revised again.
