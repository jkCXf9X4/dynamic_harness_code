---
id: AD-003
type: decision
title: "Op vocabulary split by cost"
summary: "The op vocabulary splits by cost: bounded sync ops are direct calls; indefinite or off-thread ops are yield requests serviced by the pump."
date: 2026-10-07
status: accepted
layers: [architecture]
state: breakdown/02-architecture/the-kernel-made-real.md
artifacts:
  - src/dhc/framework/pump.py
  - tests/test_imp001_acceptance.py
supersedes: []
superseded_by: []
related:
  - AD-001
  - INFO-031
  - PD-001
  - TC-001
---

# AD-003: Op vocabulary split by cost

## Context

Blocking supervision burns wall-clock: `await_` (INFO-031) blocks the parent's worker thread, so a slow child consumes the parent's turn/timeout budget for the entire wait.
The trampoline (AD-001) introduces a yield vocabulary, and the scoping question is which operations are direct workspace calls and which are `yield` requests serviced by the pump.

## Decision

Bounded, synchronous operations are direct workspace calls: `run_block(code)`, `inbox.drain`, `messenger.send`, guardrail/budget edits.
Only indefinite or off-thread operations are `yield` requests serviced by the pump: `yield Await(handle)`, `yield Poll(handle)`, `yield Sleep(t)`, and completion wakeups.
A parent can `yield Await(child)` without consuming step budget — the trampoline's core win over blocking `await_` today (INFO-037).

## Rationale

The split keeps the generator simple to author and the pump's contract tiny (one small request vocabulary), and eliminates the parent-thread-starvation failure of blocking `await_` (INFO-031) — waiting on a child no longer consumes a parent's step budget.
Bounded ops stay synchronous because they cannot hang the step; only indefinite/off-thread ops need the pump's park/resume machinery.

## Alternatives Considered

- Yield everything — an over-typed request vocabulary; harder to author and to service. Rejected.
- Call everything directly — blocking supervision burns budgets again; the parent-thread-starvation failure returns. Rejected.

## Consequences

- The pump classifies each yield as settle/wait/sleep and services it (park/resume for `Await`/`Poll`, timer for `Sleep`, completion wakeups).
- `yield Await(child)` does not consume the parent's step budget; a slow-child test must prove the parent thread is not starved.
- Whether `yield Await` replaces `await_` at the surface or coexists is an open question tracked in the IMP's risks; the default loop keeps `await_` working for backward compatibility.

## Verification

`tests/test_imp001_acceptance.py::test_d3_yield_await_no_step_budget_burn` proves a slow child does not starve the parent thread; `test_d3_await_backcompat_default_loop` proves `await_` still works on the default loop.

## Review Trigger

Revisit if the yield vocabulary grows beyond Await/Poll/Sleep, or if `yield Await` should replace `await_` at the surface (currently an open question in the IMP's risks).
