---
id: AD-010
type: decision
title: "Arch — The repo layout IS the boundary: dhc.framework (zero tools) vs dhc.tooling (the agent's composed world) vs dhc.ui (the operator's side)"
summary: The repo layout is the boundary — dhc.framework ships zero tools, dhc.tooling holds everything installed into agent REPLs, dhc.ui is the operator's side, wiring.py is the single meeting point.
date: 2026-10-09
status: accepted
layers: [architecture]
state: breakdown/03-implementation/module-map.md
artifacts:
  - src/dhc/framework
  - src/dhc/tooling/framework_tools.py
  - src/dhc/ui/state.py
  - src/dhc/ui/checkpoint.py
  - src/dhc/wiring.py
  - tests/framework
  - tests/tooling/test_framework_tools.py
supersedes: []
superseded_by: []
related: [AD-008, AD-009, PD-002, AD-011, INFO-055, INFO-058]
---

# AD-010: Arch — The repo layout IS the boundary

## Context

Decisions `AD-008` (the artifact store) and `AD-009` (direct messaging) drew the framework-vs-composed-tooling boundary in code, but the folder hierarchy still hid it:

- the framework lived in a package misleadingly named `dhc.agent` — a browser reads "agent" as agent-side, the opposite of the truth;
- the framework's own tools layer (`dhc.agent.tools`) sat INSIDE the framework package — the one place the split says no composed tool belongs;
- `dhc.agent.state` (the operator's review files) and `dhc.agent.checkpoint` (the operator's resumability, `PD-002`) — the placement debt `AD-008` named and deliberately did not move — were non-framework leaves parked in the framework package;
- `dhc.tooling` held the channels and the store, but the framework-surface tools were elsewhere, so "what an agent gets in its REPL" had no single home.

The user directive: the separation between the framework and the agent-tooling/inside-REPL artifacts must be concrete in the folder hierarchy — very clear when browsing the repo.

## Decision

**The layout IS the boundary.**
`dhc.agent` is renamed `dhc.framework` — the control loop and its guarantees (runtime, loop, agent surface, REPL, event stream, context triggers, rot policy, caps, integrity) plus the directed-message primitive (`send`, `AD-009`); the name now says what it is.
The framework package ships **zero tools**: `dhc.agent.tools` moves to `dhc.tooling.framework_tools` (the `list_tools`/`events` tools that wrap framework surfaces, installed by `register_default_tools`), so everything installed into an agent REPL namespace beyond the core actions has one home, `dhc.tooling`: `framework_tools`, `channels` + `channel_tools`, `artifact_store` + `artifact_tools`, `adapters`.
The `AD-008` placement debt is resolved by moving the files to their owning sides: `dhc.agent.state` (StateWriter — the operator's review files) → `dhc.ui.state`; `dhc.agent.checkpoint` (the operator's resumability store, `PD-002`) → `dhc.ui.checkpoint`; both are the operator's files, and `ui/` is the operator's side (door, terminal, review files, resumability).
`wiring.py` is the **single meeting point** — the only module that imports both `dhc.framework` and `dhc.tooling` (and `dhc.ui`).
Tests mirror the layout: `tests/agent` → `tests/framework`; the framework-tools tests → `tests/tooling/test_framework_tools.py` + `test_events_tool.py`; state and checkpoint tests → `tests/ui/`.

## Rationale

- The user directive: the framework/tooling separation must be concrete in the folder hierarchy — very clear when browsing the repo.
- The folder hierarchy hid the boundary `AD-008`/`AD-009` had drawn in code: a package misleadingly named `dhc.agent`, the tools layer inside the framework package, operator files parked in the framework package, and framework-surface tools outside `dhc.tooling`.

## Alternatives Considered

- **Keep the `dhc.agent` name** (clarity loses: the most important browsing signal — "this package is the framework" — stays inverted).
- **A `dhc.agent` alias re-exporting `dhc.framework`** (two homes for one package defeats the point of a browseable split).
- **A third package for the composed side** (e.g. `agentkit`): `tooling` is the established name from `AD-008`/`AD-009` and the user's own vocabulary — "channels should be a strict tooling".
- **Moving `llm/fabrication.py` in this pass**: see Consequences — the kit is framework-bootstrap-necessary (the pump cannot run without seeding a runner), so it cannot simply move to `tooling/` without inverting a dependency the guard forbids.
- **Moving `state.py`/`checkpoint.py` into `tooling/`**: both are the *operator's* files (review, resumability — `PD-002` says so explicitly); their home is the operator's side, not the agent's composed world.

## Consequences

- Positive: broad but mechanical import churn (32 `git mv` renames, no behavior changes): every `dhc.agent.X` import became `dhc.framework.X` (or the module's new home); the golden prompts and all tests pass unchanged in content.
- Positive: `dhc.agent` is gone — no alias, a clean cut (pre-1.0, the repo is the only consumer). Browsing the tree now answers the classification question at a glance: framework = what runs agents; tooling = what agents get in their REPLs; ui = the operator's side; wiring = the only meeting point.
- Positive: `tests/framework` is the slow directory (the runtime suites); the framework/tools/ui/tooling split of tests makes the suite's geography readable too.
- The guard test extends and becomes a layout test (this decision): no `dhc.framework` module may import `dhc.tooling` or `dhc.ui`; the framework package must contain no `*tools*` module; the tool homes must exist in `dhc.tooling`; state/checkpoint must live in `dhc.ui`.
- Dependency directions: framework → (`data`, `errors`) only; tooling → framework (one-way); ui → framework, tooling; wiring → all.
- Known follow-up debt, named not moved here: the fabrication kit (`llm/fabrication.py`) straddles the framework (the pump seeds the default `__runner__` from it and `integrity` re-seeds it — `framework/loop.py` and `framework/runtime.py` import it) and the composed world (wiring installs the kit into workspaces). It also imports `llm.driver`. Moving it means splitting bootstrap-necessary parts from composed parts — real surgery, out of scope. The framework → llm import direction therefore remains, guarded only against `tooling` and `ui`. **Resolved by `AD-011`:** the framework owns the pump and the runner contract (renamed `framework/pump.py`); the default agent — the whole fabrication kit — moved to `dhc.tooling.fabrication` and is handed in via `Runtime(kit_factory=...)` at the composition root; the framework now imports only `data` + `errors` (the guard also forbids `llm`).

## Verification

The layout guard test (`tests/framework/test_core_tooling_boundary.py`, extended by this decision): no `dhc.framework` module may import `dhc.tooling` or `dhc.ui`; the framework package must contain no `*tools*` module; the tool homes must exist in `dhc.tooling`; state/checkpoint must live in `dhc.ui`. Full suite green (see the run log in the commit).

## Review Trigger

If a new package appears that both the framework and tooling import, revisit the layout.
