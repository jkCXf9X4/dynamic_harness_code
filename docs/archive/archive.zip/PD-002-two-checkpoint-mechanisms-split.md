---
id: PD-002
type: decision
title: "Two checkpoint mechanisms: the split is intended (agent workspace vs operator on-disk)"
summary: "The two checkpoint mechanisms are a deliberate control split: workspace checkpoints are the agent's; the on-disk CheckpointStore is the operator's, dormant in production."
date: 2026-10-09
status: accepted
layers: [product]
state: breakdown/01-product/the-control-split-agent-vs-runtime.md
artifacts:
  - src/dhc/ui/checkpoint.py
  - src/dhc/tooling/fabrication.py
  - src/dhc/ui/terminal.py
  - src/dhc/wiring.py
  - tests/ui/test_checkpoint_split.py
  - tests/ui/test_checkpoint_trace.py
supersedes: []
superseded_by: []
related:
  - INFO-053
  - AD-008
---

# PD-002: Two checkpoint mechanisms: the split is intended (agent workspace vs operator on-disk)

## Context

`INFO-053` A3 surface: the agent's context and history are "full accumulated state as ordinary data" it can read.
Roadmap Wave 3 item H-06 (open question 4) flagged a tension: two checkpoint mechanisms coexist, and the agent cannot read its own on-disk checkpoint.

- **Workspace checkpoints** — `state["checkpoints"]` in the fabrication kit (`src/dhc/tooling/fabrication.py`, the `checkpoint`/`rollback`/`compact` citizens). Agent-owned, in-memory, part of the agent's own namespace; re-seeded by `ensure_fabrication`.
- **On-disk `CheckpointStore`** — `src/dhc/ui/checkpoint.py` (`AgentCheckpoint`/`CheckpointStore`/`CheckpointDriver`), surfaced to the operator via `/resume` in the terminal UI (`src/dhc/ui/terminal.py`).

H-06 question: is the agent's inability to read its own on-disk checkpoint an A3 violation, or a deliberate operator/agent split?

## Decision

Document the split as intended; do not unify. The on-disk store stays operator-only; the workspace checkpoints stay the agent's.

- Add a docstring to the workspace `checkpoint` citizen (`src/dhc/tooling/fabrication.py`): it is the agent's own in-workspace mechanism, distinct from the operator's on-disk `CheckpointStore`.
- Add a comment to the terminal's `/resume` handler (`src/dhc/ui/terminal.py`): it reads the operator's on-disk store, separate from the agent's workspace checkpoints.
- Add a pinning test: the on-disk store is never instantiated in production wiring, and the agent's workspace checkpoint mechanism never touches the on-disk store.

## Rationale

The on-disk `CheckpointStore` is **dormant in production**:
- never instantiated in `src/`; `wiring.py`'s `build_runtime` never sets `runtime.checkpoint_store`;
- the terminal's `/resume` handler (`getattr(self.runtime, "checkpoint_store", None)`) always resolves to `None` and reports "no checkpoint";
- exercised only by `tests/ui/test_checkpoint_trace.py` — a peripheral reference-project wrapper mirroring `core/checkpoint.py`, a tested operator-facing resumability seam, not a live mechanism.

The workspace `state["checkpoints"]` is the **live, agent-owned** counterpart: a fabrication citizen, re-seeded by `ensure_fabrication`, read and written by the agent as ordinary namespace data.

The two mechanisms are two different layers of the control split, not competing implementations of one thing.

## Alternatives Considered

- **Unify** (expose the on-disk store to the agent as a tool) — rejected for three reasons:
  - **Dormant, no writer.** No production writer, so an agent-facing tool would expose an always-empty store — no value, only surface area.
  - **Different scope.** The on-disk `AgentCheckpoint` captures a coarse snapshot (agent_id, requirement, acceptance, status, turn_counter, notes); the workspace checkpoints capture the agent's full namespace state. Unifying means a lossy projection or a redesign of the on-disk model — neither justified while the store is dormant.
  - **Blurs the control split.** The split means the agent owns its context and the operator owns the runtime's durable state. Giving the agent a read handle on the operator's store inverts that boundary for no benefit.

## Consequences

- **A3 satisfied as written.** The agent's context and history are ordinary data it can read (the workspace checkpoints); the on-disk store is the operator's durable out-of-process resumability snapshot, correctly outside the agent's context.
- **Both sites documented.** The split is now discoverable and intentional rather than an accident.
- **No behavior change.** No new dependencies; the dormant on-disk store is left as-is — a tested peripheral wrapper, ready to be wired if a future decision wants operator resumability.
- **Partial amendment (AD-008, "artifact store is tooling").** A later record supersedes only this record's classification of the on-disk store as "operator-facing runtime state": the store is operator tooling, not operator-facing runtime state. The workspace-checkpoint half of the split is untouched.

## Verification

Pinned by `tests/ui/test_checkpoint_split.py`:
- the on-disk `CheckpointStore` is never constructed in `src/dhc/wiring.py` (operator-only, dormant in production);
- the terminal's `/resume` reads the operator's `runtime.checkpoint_store` (the operator's side), not the agent's workspace checkpoints;
- the agent's workspace `checkpoint` citizen writes only to `state["checkpoints"]` and never to the on-disk store (the two mechanisms are independent).

Full suite green (473 baseline + new).

## Review Trigger

If the on-disk `CheckpointStore` is ever wired into production (a future decision), revisit agent-readability then — with a real writer and a real reason.
