---
id: IMD-002
title: Enum-driven event-kind mapping in the state snapshot
summary: The state snapshot matches EventKind members against an explicit terminal table, failing loudly at import and test time instead of dropping events.
date: 2026-10-09
status: accepted
layers: [implementation]
state: breakdown/03-implementation/state-view-model.md
artifacts:
  - src/dhc/ui/state.py
  - tests/ui/test_state.py
supersedes: []
superseded_by: []
related: [IMP-002, INFO-048, INFO-051, INFO-059]
---

# IMD-002: Enum-driven event-kind mapping in the state snapshot

## Context
`IMP-002` flags that the operator state snapshot re-derives event identity by string: `StateWriter.on_event` (then `src/dhc/agent/state.py`, lines 364-399; now `src/dhc/ui/state.py`) converts each kind with `kind.value if hasattr(kind, "value") else str(kind)` and branches on string literals (`"report"`, `"failure"`, `"escalation"`), while the rest of the codebase speaks the `EventKind` enum (`src/dhc/data/models.py`).
The hazard: renaming an `EventKind` member, or adding a new kind the snapshot should record as terminal, fails nothing — the literal no longer matches, the event falls to the `else` (activity) branch, and the snapshot view-model quietly loses the terminal classification, with no compile-time or test-time link between the enum and the branches.
Key finding (verified against source): the `"report"` and `"failure"` branches are dead code — `EventKind` has no member with value `"report"` or `"failure"`, and the typed bus validates `Event.kind: EventKind`, so a raw `"report"`/`"failure"` event cannot be constructed or published.
The only live terminal kind is `EventKind.escalation` (emitted at `ui/communication.py:235`, now `src/dhc/tooling/channels.py:234`); every other kind records as activity.
Removing the two dead string branches changes no observable output.

## Decision
Match on the `EventKind` member, not its string value, via an explicit terminal table.
A module-level `TERMINAL_EVENT_KINDS: dict[EventKind, str]` in `state.py` (importing `EventKind` from `..data.models`) is the single source of truth for which kinds the snapshot records as terminal, with `_terminal_record` building the enum-keyed record; `on_event` routes a kind to the terminal path iff `isinstance(kind, EventKind) and kind in TERMINAL_EVENT_KINDS`, and everything else records as activity.
Fail loudly at import time and test time, never drop at runtime: the snapshot is a peripheral view-model whose contract is "must never crash a snapshot", so `on_event` does not raise on an unknown kind — it records it as activity (the documented fallback, which also tolerates non-enum kinds via `str(kind)`).
1. Import time (rename of a member name): the table is keyed by `EventKind` member, not string, so renaming a member without updating the table makes `state.py` reference a non-existent member, an `AttributeError` at import — a hard, immediate failure, not a silent drop.
2. Test time (new kind or reclassification): per-kind tests publish every `EventKind` member and assert each is recorded (no silent drop), and a pinned terminal-set test asserts `set(TERMINAL_EVENT_KINDS) == {EventKind.escalation}`, so promoting a new kind to terminal is a visible, reviewable test change, not an accident.
A rename of a member's value is safe: the table is keyed by member, so routing is unaffected; only the recorded `event_type` string changes, a visible diff in the table's value.

## Rationale
- One definition, no second copy: the terminal set is the enum's members named in `TERMINAL_EVENT_KINDS`, a readable, diffable fact next to the code that uses them, not a hand-duplicated set of string literals.
- The view-model must not crash the snapshot: raising in `on_event` on an unknown kind would let one unrecognized event take down the operator overview, the exact failure mode the module avoids; recording as activity is the safe, non-dropping fallback, and loudness moves to the seams where it cannot hurt the live snapshot (import plus tests).
- Behavior parity for all reachable inputs: the only live terminal kind (`escalation`) still records the escalation record and forces a snapshot; every other reachable kind still records as activity; the two dead branches are removed because they are unreachable, so no observable output changes and the stringly-typed hazard is gone.
- The mapping is the single source of truth per the `IMP-002` containment table: a rename without updating the mapping fails loudly (import error) instead of silently dropping; a new kind is recorded only if added to the mapping, a visible, reviewable decision.

## Alternatives Considered
- Raise in `on_event` on an unknown or renamed kind (fail loudly at runtime). Rejected: it lets one unrecognized event crash the operator snapshot, violating the view-model's "must never crash a snapshot" contract; the choice is never-drop at runtime plus loud at import and test time.
- Keep the `"report"`/`"failure"` string branches as a non-enum fallback. Rejected: they are unreachable (no `EventKind` member, typed bus), so keeping them adds risk with no behavior and perpetuates the stringly-typed hazard this decision removes.
- Live the mapping beside `EventKind` in `data/models.py`. Rejected in favor of `state.py`: placing it in `state.py` keeps the snapshot's policy (which kinds are terminal for the snapshot) with its only consumer and avoids coupling the data model to a peripheral view-model concern; the table is a named, diffable constant either way.

## Consequences
- A renamed terminal member name is an import-time `AttributeError` (loud), never a silent drop; a renamed member value is a visible table diff.
- A new `EventKind` is recorded as activity by default (never dropped); making it terminal is a deliberate, test-pinned change.
- The snapshot's reachable output is byte-identical to before for all live kinds; the two dead `report`/`failure` branches are gone.
- The event-stream discipline (FIFO, at-most-once, persist-before-execute — `INFO-048`, `INFO-051`) and the `_MemoryBus` drain race are untouched (out of scope per the `IMP-002` leaf).

## Verification
Full suite green (baseline 483 passed at main `5fe29aa`; final count in the run report). No existing test is modified or weakened.
New tests, all in `tests/ui/test_state.py`:
1. `test_every_event_kind_is_recorded_not_dropped` — publishes every `EventKind` member through the bus and asserts each yields a line in `events.jsonl` (terminal or activity); the direct proof that a renamed or new kind cannot silently drop.
2. `test_terminal_kind_escalation_forces_snapshot_and_records_issue` — `EventKind.escalation` records the escalation record and forces a snapshot.
3. `test_activity_kind_records_event_type_and_throttles` — `EventKind.turn_started` records the activity record with its event type.
4. `test_terminal_table_keys_are_real_event_kinds` — asserts `set(TERMINAL_EVENT_KINDS) <= set(EventKind)`, catching a stale or renamed member name in the table.
5. `test_terminal_set_is_explicit` — pins `set(TERMINAL_EVENT_KINDS) == {EventKind.escalation}`, so promoting a new kind to terminal is a visible, reviewable test change.
6. `test_renamed_terminal_member_fails_loudly_not_silently` — proves the table is member-keyed and that referencing a renamed-away member name is a hard `AttributeError` at construction time, the import-time loud path.

## Review Trigger
None
