---
id: AD-007
title: "Single monotonic time base for all duration comparisons (H-04)"
summary: All duration comparisons use time.monotonic(); informational timestamps stay wall-clock, so wall-clock jumps can neither trip nor mask a cap.
date: 2026-10-09
status: accepted
layers: [architecture]
state: breakdown/02-architecture/the-time-base.md
artifacts:
  - src/dhc/framework/pump.py
  - src/dhc/framework/caps.py
  - tests/framework/test_composition_wave1.py
  - tests/framework/test_event_fanout.py
  - tests/framework/test_g05_parked_time.py
  - tests/framework/test_h04_monotonic_timebase.py
supersedes: []
superseded_by: []
related: [PD-001, INFO-053, INFO-060, IMP-003]
---

# AD-007: One monotonic time base for the wall-clock ceiling

## Context
The wall-clock ceiling chain mixed two clocks: the origin `started_ts` was set with `time.time()` at pump start (`loop.py:278`, now `framework/pump.py`), the ceiling's "now" side was `time.time()` inside the predicate (`caps.py:192`), while the parked-time credit measured by `service_await`/`service_sleep` used `time.monotonic()` — the mixed base `PD-001` recorded as a deferred interaction ("the parked credit and `started_ts` must move to the same monotonic base together — the subtraction is only meaningful within one clock").
A wall-clock jump (NTP correction, VM resume, manual set) moves `time.time()` without moving `time.monotonic()`, so under the mixed base it could mask a cap (a backward jump makes the elapsed term hugely negative — an over-budget agent stops tripping `wall_clock` for the rest of its run) or kill a healthy agent (a forward jump makes the elapsed term explode — an agent with hours of legitimate budget left dies instantly); both attack the exact guarantee `INFO-053` says the runtime owns (ceiling caps bind "regardless of any budget edit the agent makes" — and, a fortiori, regardless of what the wall clock does).
A full inventory of every clock call in `src/` (22 sites, archived evidence `h04_time_inventory.md` in `.dynamic-harness/261008_223605_2752/`) found exactly two wall-clock timestamp sites participating in duration math — the origin (`loop.py:278`, now `framework/pump.py`) and the comparison's "now" (`caps.py:192`) — and confirmed the parked-credit side (`loop.py:593-631`) was already monotonic; every other timeout mechanism in the tree (`repl.py` step timeout via `worker.join(timeout)`, the LLM driver's SDK timeouts and `thread.join(self.timeout)`, runtime join timeouts, all `time.sleep` polling) is a bare duration with no clock base, and the two remaining duration comparisons (`state.py:325` snapshot throttle, `benchmark/run.py:165,171` latency) were already monotonic (the full inventory now lives in `INFO-060`).

## Decision
All duration comparisons use `time.monotonic()`: the wall-clock ceiling moves to the monotonic base, origin and comparison together — `started_ts = time.monotonic()` at pump start, and the ceiling comparison becomes `time.monotonic() - started_ts - max(parked_seconds, 0.0) > timeout_seconds` in `caps.py`.
This discharges `PD-001`'s recorded interaction exactly as specified: the parked credit (already monotonic) and `started_ts` now share one base, so the subtraction is meaningful within a single clock; the credit itself needed no change — the defect was the wall-clock side.
Informational timestamps stay wall-clock: `agent.created_ts` (`framework/agent.py:135`), `agent.settled_ts` (`framework/runtime.py:567`), checkpoint `updated_at`, `events.jsonl`/`trace.jsonl` timestamps, and the `Event`/`Message`/`Turn` model defaults are records for humans and post-hoc inspection, none ever read back into a comparison (verified by consumer grep); converting them would destroy their wall-clock readability with zero correctness benefit. The name `started_ts` is kept — still a timestamp, just a monotonic one. Docstrings and the origin comment name the monotonic base and the `PD-001` interaction.

## Rationale
- The ceiling is a duration guarantee, not a calendar one: `timeout_seconds` means "this agent may not run for more than N seconds of real time", and real elapsed time is what `time.monotonic()` measures; `time.time()` additionally encodes the operator's clock discipline (NTP, jump-prone), and a guarantee the vision places in the runtime's hands must not depend on it.
- The mixed base was not merely untidy but exploitable by accident: the `PD-001` arithmetic subtracts a monotonic duration from a wall-clock elapsed, so a backward jump beyond the parked credit makes the effective elapsed negative (cap masked) and a forward jump adds phantom seconds (healthy agent killed); the jump tests pin both directions.
- Minimal and complete: the inventory shows exactly two sites carry the defect and both move in one commit; no other duration math exists in the tree, so "all duration comparisons on one monotonic base" is grep-verifiable — after this change no `time.time()` remains in any duration comparison.
- Records stay honest: keeping `created_ts`/`settled_ts`/event timestamps on wall clock preserves their meaning ("when did this happen, in human time"), their existing test assertions, and a minimal diff.

## Alternatives Considered
- Keep wall clock everywhere (convert the credit to wall). Rejected: the credit is a duration measured across a park; wall-clock jumps during the park would corrupt the credit itself (a backward jump could make a 5 s park measure as -3600 s, un-crediting time and killing a healthy parked agent — the exact anti-pattern `PD-001` exists to prevent).
- A dedicated clock seam (injectable `clock=` callable). Rejected for now: no test or caller needs to inject a clock (the jump tests monkeypatch `time.time` at the module seam, which is enough), and a new seam is a new surface to maintain; the two-line change achieves the guarantee without it.
- Convert informational timestamps to monotonic too. Rejected: records must stay wall-clock readable; none is read back into a comparison.

## Consequences
- The wall-clock ceiling is immune to wall-clock jumps in both directions: a jump can neither trip nor mask a cap.
- `started_ts` is a monotonic timestamp; anything that persisted it across process restarts would be meaningless — nothing does (it is a per-run local in `pump_loop`, verified by consumer grep).
- The three test files that inject `started_ts` values now inject monotonic values; future tests that force the ceiling must use `time.monotonic()` (pinned by the source-invariant test).
- `PD-001`'s recorded interaction is discharged: the parked credit and `started_ts` are on the same monotonic base, and the composition test pins that they compose.

## Verification
Full suite green (see the run log in the commit). New tests, all in `tests/framework/test_h04_monotonic_timebase.py`:
1. `test_h04_wall_clock_jump_forward_does_not_trip` — a busy agent under a 5 s ceiling survives a simulated +3600 s wall-clock jump mid-run; no `wall_clock` crash event; the agent completes.
2. `test_h04_wall_clock_jump_backward_does_not_mask` — a busy agent under a 0.2 s ceiling is still killed by `wall_clock` despite a simulated -3600 s wall-clock jump mid-run; the crash event names cap and limit.
3. `test_h04_parked_credit_and_started_ts_same_base` — pins the `PD-001` interaction directly at the predicate seam: with `started_ts` from `time.monotonic()`, a wall-clock jump of ±3600 s changes nothing about the trip decision.
4. `test_h04_no_wall_clock_in_duration_math` — grep-able invariant: no `time.time()` remains in `caps.py`/`pump.py` duration math; guards against regression to a mixed base.
The clamp+credit composition test (`test_composition_wave1.py`) stays green with the base flip — the three `started_ts` injections there flip from `time.time() - 10.0` to `time.monotonic() - 10.0`, the decision-required pinning update, not a weakening: the test still pins the identical arithmetic (10 s elapsed / 6 s credit / 5 s ceiling) on the base the predicate actually reads (a `time.time()`-based injection would make the elapsed term hugely negative against a monotonic `started_ts` and the ceiling would silently stop tripping — the test would pass vacuously). Six `started_ts` injections in `test_event_fanout.py` and three in `test_g05_parked_time.py` flip for the same reason.

## Review Trigger
None
