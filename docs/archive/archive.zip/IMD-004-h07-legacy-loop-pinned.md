---
id: IMD-004
type: decision
title: "H-07 — The legacy loop path is required by the bare in-memory core: pinned, not retired"
summary: The legacy turn loop stays pinned as the loop of the bare in-memory core, because _MemoryEngine has no pump primitives and the CLI plus core contract tests run on it.
date: 2026-10-09
status: accepted
layers: [implementation]
state: breakdown/03-implementation/module-map.md
artifacts:
  - src/dhc/framework/pump.py
  - src/dhc/cli.py
  - src/dhc/wiring.py
  - tests/framework/test_h07_legacy_loop.py
  - tests/framework/test_runtime.py
supersedes: []
superseded_by: []
related: [IMD-001, AD-008, AD-011, INFO-055, INFO-058]
---

# IMD-004: H-07 — The legacy loop path is required by the bare in-memory core: pinned, not retired

## Context

`src/dhc/agent/loop.py` (now `src/dhc/framework/pump.py`, `AD-011`) carried two loop implementations behind a dispatch:

- `pump_loop` (`loop.py:241`) — the pumped path: drives the agent's `__runner` generator one yield-window at a time under the four hard gates (settlement, containment, ceiling caps, cancellation) plus the caps watchdog and the rot tripwire. The main path for every wired runtime (`build_runtime`, `src/dhc/wiring.py:402-409`).
- `legacy_loop` (`loop.py:144`) — the exact old `_worker_loop` body: decide → execute → settle, turn-based, no caps watchdog, no rot gate.
- The dispatch: `pump_agent` (`loop.py:130-141`) calls `runtime._supports_pump()`; `supports_pump` (`loop.py:93`) is true when `runtime.repl_engine` is set **or** `runtime.engine` has `advance`.

The roadmap (H-07, gap-analysis §C Wave 3; §D open question 2) asked whether the legacy path is "dead weight from the pre-pump era" that can be removed, or a live surface that must stay.

Investigation evidence (decision-time locations): `ReplEngine` (`src/dhc/agent/repl.py:55`) has all eight pump primitives — pump; `_ReplEngineAdapter` (`src/dhc/wiring.py:188`, with `runtime.repl_engine` set alongside at `wiring.py:409`) — pump; `_MemoryEngine` (`src/dhc/agent/runtime.py:75`) has none, only `execute` — legacy. `TracingEngine` (`src/dhc/data/trace.py:114`) is a test-surface wrapper used directly against an engine (`tests/agent/test_checkpoint_trace.py`), never installed as a `Runtime` engine — not a loop consumer. `test_runtime.py:707` records the split explicitly: "The legacy in-memory path is covered by the tests above (make_runtime)." The engine matrix and consumer list now live in `INFO-055`; the bare-vs-wired distinction in `INFO-058`.

## Decision

**Pin the legacy path.** `legacy_loop`, `supports_pump`, and the `pump_agent` dispatch stay, documented and pinned by `tests/agent/test_h07_legacy_loop.py` (now `tests/framework/`, `AD-010`).
The legacy path is the loop of the *bare in-memory core* — the engine-agnostic `Runtime(engine, bus, store)` of `IMD-001`'s module separation — not a duplicate of the pump.
No production code changes: pinning is the decision; the only new artifact is the pinning test.

## Rationale

- **An engine genuinely needs it.** The pump is not a loop over `execute`; it is a loop over the ReplEngine's resumable-runner primitives (`install`/`advance`/`inject`/`kill`/`suspend`/`resume`/`globals_for`/`has_workspace`). `_MemoryEngine` has none of them, by design: it is the minimal turn-based core. The parent's retirement condition — "if retiring turns out to require more than a decision + removal (e.g. engines genuinely need it), pin it" — is met.
- **Retiring means one of two larger changes, both worse.** Migrating every bare-`Runtime` user to the wired runtime: the CLI would move from a zero-footprint in-memory core to the full wired stack (workspace dirs, artifact store, fabrication kit) — a behavior change to a production entry point — and ~30 core contract tests would need the `_pumped_runtime(tmp_path)` fixture shape. That is a migration project, not a removal. Giving `_MemoryEngine` the pump primitives: that is re-implementing `ReplEngine` (snapshot/rollback, per-step timeout, suspend/resume) a second time — strictly more dual-maintenance surface than the ~100-line turn loop it would delete.
- **The two loops are not two implementations of one thing.** The pump is the agent-owned-loop path (fabrication kit, `__runner`, yield vocabulary, caps, rot). The legacy loop is the *engine-agnostic core's* turn loop — the seam that keeps `runtime.py` free of any REPL dependency (`IMD-001`). Deleting it does not remove a duplicate; it removes the core's only loop.
- **The cost of pinning is bounded and now explicit.** Before this decision the split was an undocumented "known defect" (gap-analysis §B small defect 5). After it, the requirement, its consumers, and its limitation (below) are recorded once in a decision record and enforced by a test that fails if the dispatch or the path silently changes.

## Alternatives Considered

- **Retire: remove `legacy_loop` + `supports_pump` dispatch, migrate the consumers.** Rejected on Rationale 2 — it is a CLI behavior change plus a ~30-test migration, exactly the scope explosion the retirement option was conditioned on not needing.
- **Retire: implement the pump primitives on `_MemoryEngine`.** Rejected on Rationale 2 — a second `ReplEngine` to maintain is more duplicated surface than the loop it deletes.
- **Retire: make `Runtime()` default to `ReplEngine`.** Rejected: it couples the engine-agnostic core to the REPL (against `IMD-001`'s module separation) and silently changes the CLI's footprint and behavior.

## Consequences

- Positive: the legacy path stays as the bare core's loop; the dispatch (`supports_pump`) remains the single seam that routes an agent to it. The requirement, consumers, and limitation are recorded and test-pinned.
- Positive: the previously undocumented legacy/pump split (gap-analysis §B small defect 5) is now documented here.
- Negative: the legacy path enforces no ceiling caps and no rot tripwire between turns (those are pump gates). The bare in-memory core is the minimal engine-agnostic runtime; the wired runtime — the path the vision's agent-owned loop describes (`INFO-001`, `INFO-052`) — enforces all four hard gates. This is pre-existing behavior, now recorded.
- If the CLI ever migrates to `build_runtime` (a product decision, not a hygiene one), the legacy consumers shrink to the core contract tests.

## Verification

Full suite green (see the run log in the commit). New tests, all in `tests/agent/test_h07_legacy_loop.py` (now `tests/framework/`, `AD-010`):

1. `test_h07_bare_runtime_falls_back_to_legacy` — a bare `Runtime()` (the CLI's shape, `cli.py:130`) reports `supports_pump() is False`: the dispatch condition is pinned.
2. `test_h07_wired_runtime_uses_pump` — the wired runtime (`build_runtime`) reports `supports_pump() is True`: the main path is the pump, and the dispatch never sends a wired agent to legacy.
3. `test_h07_legacy_path_drives_bare_runtime_agents` — an agent spawned on a bare `Runtime()` completes, and its event stream carries the legacy path's `turn_started` payload shape (`{"code": ...}`, the turn loop's) rather than the pump's (`{"step": ...}`): the path is exercised end-to-end, not dead code.
4. `test_h07_memory_engine_lacks_pump_primitives` — the mechanical reason, pinned: `_MemoryEngine` has none of the eight primitives the pump requires.
5. `test_h07_repl_engine_provides_pump_primitives` — the contrast: `ReplEngine` provides all eight, so the pump's contract is real, not vacuous.

## Review Trigger

If the CLI migrates to `build_runtime`, or `_MemoryEngine` gains pump primitives, revisit this pin.
