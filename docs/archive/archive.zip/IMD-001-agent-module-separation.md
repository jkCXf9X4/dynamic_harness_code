---
id: IMD-001
title: "Agent module separation: loop, caps, integrity, and context triggers extracted from runtime.py"
summary: The 1058-line runtime.py god object is split by concern into loop, caps, integrity, and context modules behind a re-export facade, with behavior and the public API unchanged.
date: 2026-10-08
status: accepted
layers: [implementation]
state: breakdown/03-implementation/module-map.md
artifacts:
  - src/dhc/framework/pump.py
  - src/dhc/framework/caps.py
  - src/dhc/framework/integrity.py
  - src/dhc/framework/context.py
  - src/dhc/framework/runtime.py
  - src/dhc/wiring.py
  - tests/framework/test_context.py
  - tests/framework/test_event_fanout.py
supersedes: []
superseded_by: []
related: [AD-002, AD-004, IMP-002, IMP-003, IMP-004, INFO-021, INFO-046, INFO-048, INFO-055, IMD-004]
---

# IMD-001: Agent module separation — loop, caps, integrity, and context triggers out of `runtime.py`

## Context
The scoping brief (run `261008_105638_6a18`) found three concerns entangled in one 1058-line god object (`src/dhc/agent/runtime.py`, now `src/dhc/framework/runtime.py`) sharing one lock and one mutable frame: the agent loop (`_pump_loop`, 236 lines, inlined the caps watchdog, completion drain, fabrication re-seed, runner install, and yield servicing, with `_settle`/`_emit`/`_build_namespace` beside it), context triggers (no prune/compress/summarize module; three scattered mechanisms — a dormant `ContextRotDetector`, the trim-50 digest, the caps tripwires — could not be evolved or tested until separable), and tool calls (`tools.py`, already its own module, stayed put).
Eight coupling points resisted separation (the brief's §2, now the `IMP-002`/`IMP-003`/`IMP-004` leaves): the destructive `_MemoryBus.drain` race, the Runtime god object, the fabrication kit closing over runtime privates, reflective state reads, the kit-dict double role, three wall-clock bases, stringly-typed event kinds, and two parallel loop bodies.
This record covers the pure extraction that followed: behavior unchanged, public API unchanged, no new dependencies, no reformatting — a separate, reviewable diff from the drain-race fix.

## Decision
Option A, the scoping brief's §5 recommendation: a package split by concern, capturing the seams that already existed (a pure caps predicate, a duck-typed rot detector needing one wiring line, and `ctx["observe"]` around the only real pruning) at moderate risk, without Option C's larger blast radius.
New modules under `src/dhc/agent/` (now `src/dhc/framework/`): `loop.py` (the loop concern, now `pump.py` per `AD-011`), `caps.py` (the ceiling-caps watchdog predicate), `integrity.py` (fabrication ensure/re-seed), and `context.py` (the context-trigger seam); `runtime.py` re-exports the moved callables so the public API is unchanged; `tools.py` is untouched.
`runtime.py` went 1058 to 595 lines; `loop.py` (562 lines) owns `pump_agent`, `pump_loop`, `legacy_loop`, the yield vocabulary (`Await`/`Poll`/`Sleep`), and `install_runner`/`service_await`/`service_sleep`/`step_timeout`/`supports_pump`; `caps.py` (113 lines) the watchdog predicate plus the five ceiling-cap defaults; `integrity.py` (38 lines) the best-effort `ensure_fabrication` re-seed calls (`AD-004`); `context.py` (62 lines) `DIGEST_KEEP = 50`, `trim_digest`, and `make_observe`, with `fabrication.py`'s `make_observe` a thin delegate and `driver_from_settings` gaining a `rot_detector` parameter so `build_runtime` constructs a `ContextRotDetector` (`INFO-021`, observe-only) and the driver's per-block observation actually collects.
The eight moved loop callables are re-exported from `runtime.py` (verified 8/8 `is`-identical to `dhc.agent.loop`); two `TestDetectorWiring` failures from the prior run are resolved in `tests/test_context.py` (now `tests/framework/test_context.py`, 299 lines, four classes: `TestTrimDigest`, `TestObserveDigest`, `TestMakeObserve`, `TestDetectorWiring`).

## Rationale
- The god object mixed the loop, the caps watchdog, fabrication integrity, and context triggers in one file with one lock and one mutable frame, so none of the four concerns could be evolved or tested separately.
- The seams already existed: a pure caps predicate, a duck-typed rot detector needing one wiring line, and `ctx["observe"]` around the only real pruning — the split formalizes boundaries the code already implied.
- Option A captures those seams at moderate risk while leaving the larger protocol/registry rewrite (Option C) to follow incrementally once the modules exist.
- The split is deliberately bounded: behavior unchanged, public API unchanged, no new dependencies, no reformatting — a reviewable diff separate from the drain-race fix.

## Alternatives Considered
- Option B, single-module split — extract only the caps watchdog, fabrication ensure, yield servicing, and context observe; `runtime.py` keeps the dicts and lock. Rejected: smallest blast radius, but leaves the god object and the sharpest hazard (the drain race) in place.
- Option C, protocol + registry seams — formalize Driver/CapMonitor/ContextTrigger protocols plus a ToolRegistry and a non-destructive bus peek/fan-out. Rejected for now: largest blast radius (wiring root, fabrication kit, all tool callables, bus semantics); changed drain semantics can starve or duplicate events if wrong. Its registry work can follow incrementally once the modules exist.

## Consequences
- `runtime.py` is an orchestrator plus a re-export facade; the loop, caps, integrity, and context concerns each live in their own module behind an explicit seam (module map: `INFO-055`).
- The context-trigger seam is explicit and testable; the dormant rot detector is wired at the composition root, observe-only.
- The public API (`dhc.cli:main`, the Runtime contract, `build_runtime`, `register_default_tools`) is unchanged; `AD-002`'s four hard gates stay pump-owned; the fabrication kit remains the only backward-compat path (`AD-004`).
- The `_MemoryBus` drain race is fixed in the same record (commit `2605b44`): every bus exposes a non-destructive `peek()` alongside the destructive `drain()`, and each consumer keeps its own cursor — the current-state facts live in `INFO-048`, proven by `tests/framework/test_event_fanout.py`.
- The three open hazards are tracked as `IMP-002` (stringly-typed event kinds, resolved by `IMD-002`), `IMP-003` (wall-clock bases, resolved by `AD-007`), and `IMP-004` (inert token fields, resolved by `IMD-003`).

## Verification
Independently verified (do not re-run): full suite 416 passed / 0 failed (371.04s), up from the 394-test pre-refactor baseline; re-exports 8/8; `AD-002` Phase-2 hard gates (d)–(g) all pass (settlement at-most-once, crash containment, ceiling caps, cancellation grace). Evidence: `.dynamic-harness/verify/spot/EVIDENCE.md` (archived `5fcbc3da3038`).

## Review Trigger
None
